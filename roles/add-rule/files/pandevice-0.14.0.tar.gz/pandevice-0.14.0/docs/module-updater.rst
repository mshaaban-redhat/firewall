Module: updater
===============

Inheritance diagram
-------------------

.. inheritance-diagram:: pandevice.updater
   :parts: 1

Class Reference
---------------

.. automodule:: pandevice.updater
