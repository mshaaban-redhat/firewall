Module: policies
================

Inheritance diagram
-------------------

.. inheritance-diagram:: pandevice.policies
   :parts: 1

Configuration tree diagram
--------------------------

.. graphviz:: _diagrams/pandevice.policies.dot 

Class Reference
---------------

.. automodule:: pandevice.policies
