Module: predefined
==================

Inheritance diagram
-------------------

.. inheritance-diagram:: pandevice.predefined
   :parts: 1

Class Reference
---------------

.. automodule:: pandevice.predefined
